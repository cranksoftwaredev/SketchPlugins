//This writes out a DOM object

@import "common.js"
@import "image-utils.js"

//Walk through the DOM model starting with the root and then traversing through the tree
function getChildModelElements(modelElement) {
	var type = modelElement.getType()
	if (type == "app") {
		return modelElement.getScreens();
	} else if (type == "screen") {
    	return modelElement.getLayers();
	} else if (type == "layer") {
		return modelElement.getControls();
	} else if (type == "group") {
		return modelElement.getControls();
	} else if (type == "control") {
		return modelElement.getRenderExtensions();
	} else if (type == "rext") {
		return null;
	} else {
		return null;
	}
}

function visitElement(dom, modelElement, visitorCB) {
	visitorCB(dom, modelElement, 0);

	var kids = getChildModelElements(modelElement);
	if (kids != null && kids.count() > 0) {
		for (var k = 0; k < kids.count(); k++) {
			var kid = kids.objectAtIndex(k);
			visitElement(dom, kid, visitorCB);
		}
	}

	visitorCB(dom, modelElement, 1);
}

function visitDOM(dom, visitorCB) {
	visitElement(dom, dom, visitorCB);
}

function getDOMPrintVisitor() {
	var indent = 0;

	return function(dom, modelElement, state) {
		var name = modelElement.getName();
		var type = modelElement.getType();
		if(state == 0) {
			indent = indent + 1;
			var extra = ""
			switch(type) {
			case "control":
				extra = " @" + modelElement.getX() + "," + modelElement.getY();
				extra += " [" + modelElement.getWidth() + "x" + modelElement.getHeight() + "]";
				break;
			case "rext":
				extra = " " + modelElement.getImageResourceName();
				break;
			}
			var space = Array(indent + 1).join(" ");
			log("> " + space + "[" + type + "]:" + name + extra);
		} else {
			if(type != "rext") {		//rext are leaf nodes, only show entry
				var space = Array(indent + 1).join(" ");
				log("< " + space + "[" + type + "]:" + name);
			}

			indent = indent - 1;
		}
	}
}


function writeGAPPNode(dom, modelElement) {
		var buffer = [];

		var type = modelElement.getType();
		if(type == "app") {
			buffer.push('<?xml version="1.0" encoding="UTF-8" standalone="no"?>');
			buffer.push('<gapp name="" version="3.0">');
			buffer.push(' <dimension format="ARGB888"');
			buffer.push('  height="' + modelElement.getHeight() + '"');
			buffer.push('  width="' + modelElement.getWidth() + '" />');
			buffer.push('<layers>');
			var layers = modelElement.getLayers();
			for(var l=0; l < layers.count(); l++) {
				var layer = layers.objectAtIndex(l);
				var layerNode = writeGAPPNode(dom, layer)
				if(layerNode && layerNode.length) {
					buffer.push(layerNode);
				}
			}
			buffer.push('</layers>');
			buffer.push('<screens>');
			var screens = modelElement.getScreens();
			for(var s=0; s < screens.count(); s++) {
				var screen = screens.objectAtIndex(s);
				var screenNode = writeGAPPNode(dom, screen);
				if(screenNode && screenNode.length) {
					buffer.push(screenNode);
				}
			}
			buffer.push('</screens>');
			buffer.push('</gapp>');
		} else if(type == "screen") {
			buffer.push('<screen ');
			buffer.push(' name="' + modelElement.getName() + '"');
			buffer.push('>');
			var layers = modelElement.getLayers();
			for(var l=0; l < layers.count(); l++) {
				//TODO: Move this to a layer instance ...
				var layer = layers.objectAtIndex(l);
				buffer.push('<instance');
				buffer.push(' alpha="255"');
				buffer.push(' hidden="0"');
				buffer.push(' index="' + l + '"');
				buffer.push(' layer="' + layer.getName() + '"');
				buffer.push(' opaque="0"');
				buffer.push(' x="' + layer.getX() + '"');
				buffer.push(' y="' + layer.getY() + '"');
				buffer.push('/>');
			}
			buffer.push('</screen>')
		} else if(type == "layer") {
			buffer.push('<layer ')
			buffer.push(' height="' + Math.round(modelElement.getHeight()) + '"');
			buffer.push(' name="' + modelElement.getName() + '"');
			buffer.push(' width="' + Math.round(modelElement.getWidth()) + '"');
			buffer.push('>');
			var controls = modelElement.getControls();
			for(var c=0; c < controls.count(); c++) {
				var control = controls.objectAtIndex(c);
				var controlNode = writeGAPPNode(dom, control);
				if(controlNode && controlNode.length) {
					buffer.push(controlNode);
				}
			}
			//TODO: Pull the controls
			buffer.push('</layer>')
		} else if(type == "group") {
			buffer.push('<group ');
			buffer.push(' hidden="0"');
			buffer.push(' name="' + modelElement.getName() + '"')
			buffer.push(' x="' + Math.round(modelElement.getX()) + '"');
			buffer.push(' y="' + Math.round(modelElement.getY()) + '"');
			buffer.push('>');
			buffer.push('<controls>')
			var controls = modelElement.getControls();
			for(var c=0; c < controls.count(); c++) {
				var control = controls.objectAtIndex(c);
				var controlNode = writeGAPPNode(dom, control);
				if(controlNode && controlNode.length) {
					buffer.push(controlNode);
				}
			}
			buffer.push('</controls>')
			buffer.push('</group>');
		} else if(type == "control") {
			var isVisible = modelElement.getVisible();
			var hiddenAttr = (isVisible) ? 0 : 1;
			buffer.push('<control ');
			buffer.push(' active="1"');
			buffer.push(' height="' + Math.round(modelElement.getHeight()) + '"');
			buffer.push(' hidden="' + hiddenAttr + '"');
			buffer.push(' name="' + modelElement.getName() + '"')
			buffer.push(' opaque="1"');
			buffer.push(' width="' + Math.round(modelElement.getWidth()) + '"');
			buffer.push(' x="' + Math.round(modelElement.getX()) + '"');
			buffer.push(' y="' + Math.round(modelElement.getY()) + '"');
			buffer.push('>');
			var renderExtensions = modelElement.getRenderExtensions();
			for(i = 0; i < renderExtensions.count(); i++) {
				var rext = renderExtensions.objectAtIndex(i);
				var rextNode = writeGAPPNode(dom, rext);
				if(rextNode && rextNode.length) {
					buffer.push(rextNode);
				}
			}
			buffer.push('</control>');
		} else if(type == "rext") {
			//TODO: Switch on something other than name ... we might actually have names
			var name = modelElement.getName();
			var resourceName = modelElement.getImageResourceName();
			if(name == "fill" && resourceName == undefined) {
				buffer.push('<render handler="fill">');
				buffer.push('<arg k="alpha">' + modelElement.getGAPPAlpha() + '</arg>');
				buffer.push('<arg k="color">' + modelElement.getFillColor() + '</arg>');
		    	buffer.push('<arg k="halign">' + modelElement.getGAPPHAlign() + '</arg>');
		        buffer.push('<arg k="valign">1</arg>');
		        buffer.push('</render>')
			} else if(resourceName != undefined) {		//Everything else is an image
				buffer.push('<render handler="image">');
				buffer.push('<arg k="alpha">' + modelElement.getGAPPAlpha() + '</arg>');
		    	buffer.push('<arg k="halign">' + modelElement.getGAPPHAlign() + '</arg>');
		        buffer.push('<arg k="name">' + resourceName + '</arg>');
				buffer.push('<arg k="x">' + Math.round(modelElement.x) + '</arg>');
				buffer.push('<arg k="y">' + Math.round(modelElement.y) + '</arg>');
		        buffer.push('<arg k="valign">' + modelElement.getGAPPVAlign() + '</arg>');
		        buffer.push('</render>')
			}

		} else {
			log("Unhandled gapp export of type: " + type);
		}

		if(buffer.count() == 0) {
			return null;
		}

		return buffer.join(" ");
}

function writeGAPPFile(dom, filename) {
	var gappContent = writeGAPPNode(dom, dom);
	var gappString = [NSString stringWithFormat:"%@", gappContent];
	[gappString writeToFile:filename atomically:true encoding:NSUTF8StringEncoding error:nil];
}

function exportAssets(doc, modelElement, baseDir) {
	var sourceLayer = modelElement.getSourceLayer();
	if(!sourceLayer) {
		return;
	}

	var resourceName = modelElement.getImageResourceName();
	if(!resourceName) {
		return;
	}

	var filename = baseDir + "/" + resourceName;
//	log("Export asset " + modelElement.getName() + " to " + filename);

	exportLayerAsPNG(doc, sourceLayer, filename, 1.0, 4, false);
}

function writeGAPPAssets(doc, dom, basename) {
	var fn = function(dom, modelElement, state) {
		var type = modelElement.getType();
		if(state != 0 || type != "rext") {
			return;
		}
		exportAssets(doc, modelElement, basename);
	}
	visitDOM(dom, fn);
}
