
function copyLayer(originalSlice, scaleFactor) {
  var copy = [originalSlice duplicate];
  var rect;
  if ([MSSliceTrimming respondsToSelector:"trimmedRectForLayerAncestry:"]) {
    var copyLayer = [MSImmutableLayerAncestry ancestryWithMSLayer:copy];
    rect = [MSSliceTrimming trimmedRectForLayerAncestry:copyLayer];
  }else {
    rect = [MSSliceTrimming trimmedRectForSlice:copy];
  }
  var slice = [MSExportRequest new];
  slice.rect = rect;
  slice.scale = scaleFactor;
  [copy removeFromParent];
  return slice;
}

function hasChildren(layer) {
  if ([layer isMemberOfClass:[MSLayerGroup class]]) {
    var subLayers = [layer layers];
    for (var i = 0; i < [subLayers count]; i++) {
      var subLayer = subLayers.objectAtIndex(i);
      if ([subLayer hasClippingMask]) {
        return false;
      }
    }
  }
  return ([layer isMemberOfClass:[MSLayerGroup class]]
          || [layer isMemberOfClass:[MSArtboardGroup class]]);
}

function exportLayerAsPNG(doc, layer, path, scale, depth, hasBG) {
	//TODO: Have a filter for hiding/showing this information
	//log("Saving " + layer.name() + " to file " + path);
	if (!hasChildren(layer)) {
	}

	//This method provided a slice of the Artboard but composited with overlaid content
	//var slice = copyLayer(layer, scale);
	//doc.saveArtboardOrSlice_toFile(slice, path);

	//We can't export non-visible layers, so temporarily flip the visibility
	//We assume that if you are calling this routine you want an image, otherwise
	//don't call this routine for non-visible content.
	var layerVisible = layer.isVisible();
	if(!layerVisible) {
		layer.setIsVisible(true);
	}

	//This method is much more manual and relies on export requests being available
	var requests = MSExportRequest.exportRequestsFromExportableLayer(layer)
	//var sliceLayerAncestry = [MSImmutableLayerAncestry ancestryWithMSLayer:layer];
	//var rect = [MSSliceTrimming trimmedRectForLayerAncestry:sliceLayerAncestry];
	//var requests = MSExportRequest.exportRequestsFromExportableLayer(layer, inRect:rect, useIDForName:false)
	if(!requests || requests.count() <= 0) {
		log("WARNING: No exportable content on layer " + layer.name());
		return;
	} else if(requests.count() > 1) {
		log("WARNING: More than one export request on layer " + layer.name());
	}
	var slice = requests.objectAtIndex(0);
	//Options I've found ...
	//slice.shouldTrim = false;

	//Take the output path and remove the filename
	dirPath = path.substring(0, path.lastIndexOf('/'));

	//For this export to work, the path has to be already present
	var dirNSString = NSString.pathWithComponents([dirPath]);
	NSFileManager.defaultManager().createDirectoryAtPath_withIntermediateDirectories_attributes_error(dirNSString, true, null, null);

	//Perform the export to a byte array and save the content
	var filenameNSString = NSString.pathWithComponents([path]);
	//log("Exporting something ... " + filenameNSString);
	var render = MSExporter.exporterForRequest_colorSpace(slice, NSColorSpace.sRGBColorSpace());
	render.data().writeToFile_atomically(filenameNSString, true);

	//If we flipped the visiblity to export it, then roll it back
	if(!layerVisible) {
		layer.setIsVisible(false);
	}
}

/**
 * This converts an MSColor object with RGBA 0-1 to a packed integer color
 * @param color An MSColor object
 * @return An integer value with the RGB color packed
 */
function makeRGBIntegerFromMSColor(color) {
	var rInt = Math.trunc(255 * color.red());
	var gInt = Math.trunc(255 * color.green());
	var bInt = Math.trunc(255 * color.blue());
	var aInt = Math.trunc(255 * color.alpha());
	//log("Color convert " + color.alpha() + "," + color.red() + "," + color.green() + "," + color.blue() + " to " + aInt + ","+ rInt + "," + gInt + "," + bInt)
	//return (aInt << 24) | (rInt << 16) | (gInt << 8) | bInt;
	return (rInt << 16) | (gInt << 8) | bInt;
}
