/**
 * This module is used for the assembly of a Storyboard'ish DOM based on
 * sketch content.  The generic DOM objects all provide a generic API:
 * - getType()
 *   : A string indicating the type of model object (app, screen, layer, group, control, rext)
 * - getName()
 *   : A string indicating the name of the model object, sanitized for export
 * TODO: - getChildren()
 */

@import "common.js"
@import "image-utils.js"

function domlog(msg) {
	log("SBDOM: " + msg)
}

//This routine is used to ensure that we have names that only contain
//[A-Za-z_0-9_]  We can improve this later, but this will stop Designer
//from complaining about mis-formed names with spaces in them
function sanitizeName(baseName) {
	//log("SanitizeName:<[" + baseName + "]");
	//This is an odd thing to have to do ...
	if(typeof(baseName) == "number") {
		baseName = baseName.toString();
	}
	baseName = baseName.replace(/ /g, "_");
	baseName = baseName.replace(/[^A-Za-z0-9_]/g, "");
	//TODO: Use the same character -> mnemonic replacemetn as Designer
	//log("SanitizeName:>[" + baseName + "]");
	return baseName;
}

/**
 * This is a generic function for iterating through a list of named
 * things and then matching against a name for those things.
 *@itemList An array/list of items whose names are compared
 *@itemNameMaker A function that takes an item from the list and returns its name
 *@nameMaker A function that takes an index and makes a new name based on that index
 */
function genericGetUniqueName(itemList, itemNameMaker, nameMaker) {
	var itemCount = itemList.count();
	var idx;

	for (var i = 0; true; i++) {
	  var newName = nameMaker(i);

	  for(idx = 0; idx < itemCount; idx++) {
		  var item = itemList.objectAtIndex(idx);
		  var itemName = itemNameMaker(item);
		  if(itemName == newName) {
			  break;
		  }
	  }
	  if(idx >= itemCount) {
		  return newName;
	  }
	}
}

//Run through a list of objects that provide a 'getName() API and generate
//a unique name based on a base name.  The base Name will be sanitized '
function getPeerUniqueName(baseName, itemList) {
	baseName = sanitizeName(baseName);
	if(baseName == "") {
		baseName = "object"
	}

	var itemNameMaker = function(item) {
		return item.getName();
	}
	var nameMaker = function(idx) {
		if(idx == 0) {
			return baseName;
 		} else {
			return baseName + idx;
		}
	}
	return genericGetUniqueName(itemList, itemNameMaker, nameMaker)
}

var StoryboardDOM = function(context) {
	this.type = "app";
	this.context = context;

	this.screens = [];
	this.layers = [];
	this.resourceNames = []
	this.width = 0;
	this.height = 0;

	this.addLayer = function(layer) {
	  this.layers.push(layer);
	};

	this.addScreen = function(screen) {
		var isFirstScreen = (this.screens.count() == 0);

		this.screens.push(screen);

		//Size the app to the largest screen
		if(screen.getWidth() > this.width) {
			this.width = screen.getWidth();
		}
		if(screen.getHeight() > this.height) {
			this.height = screen.getHeight();
		}

		//When a screen is added, cycle through it's layers and identify candidates
		var screenLayers = screen.getLayers()
		for(var sl = 0; sl < screenLayers.count(); sl++) {
			var screenLayer = screenLayers.objectAtIndex(sl);
			var found = false;
			for(var i = 0; i < this.layers.count(); i++) {
				var layer = this.layers.objectAtIndex(i);
				if(layer.getName() == screenLayer.getName()) {
					found = true;
					break;
				}
			}
			if(!found) {
				this.addLayer(screenLayer);
			}
		}
	};

	/**
	 * Return an image name that is unique among all image names
	 */
	this.getUniqueImageName = function(baseName) {
		var fileSystemBaseName = "images/" + sanitizeName(baseName);
		var extension = ".png";

		var itemNameMaker = function(item) {
			return item;
		}
		var nameMaker = function(idx) {
			if(idx == 0) {
				return fileSystemBaseName + extension;
	 		} else {
				return fileSystemBaseName + idx + extension;
			}
		}
		var newImageName = genericGetUniqueName(this.resourceNames, itemNameMaker, nameMaker);

		this.resourceNames.push(newImageName);

		return newImageName;
	};

	// ensure that the width and height are integers
	this.width = Math.floor(this.width);
	this.height = Math.floor(this.height);

	this.getType = function() { return this.type; }
	this.getName = function() { return ""; }
	this.getScreens = function() { return this.screens; }
	this.getLayers = function() { return this.layers; }
	this.getWidth = function() { return this.width; };
	this.getHeight = function() { return this.height; };
}

function ScreenDOM(name, width, height, layers) {
	if(layers == null || layers == undefined) {
		layers = [];
	}

	this.type = "screen";
	this.name = name;
	this.x = 0;
	this.y = 0;
	this.width = width;
	this.height = height;
	this.layers = layers;

	this.addLayer = function(domLayer) {
		//Sanity check to see if we already had the layer
		for(var i = 0; i < this.layers.count(); i++) {
			var item = this.layers.objectAtIndex(i);
			if(item == domLayer) {
				return;
			}
		}

		this.layers.push(domLayer);
	}

	// ensure that the x, y, width, and height are integers
	this.x = Math.floor(this.x);
	this.y = Math.floor(this.y);
	this.width = Math.floor(this.width);
	this.height = Math.floor(this.height);

	this.getType = function() { return this.type; };
	this.getName = function() { return this,name; };
	this.getX = function() { return this.x; };
	this.getY = function() { return this.y; };
	this.getWidth = function() { return this.width; };
	this.getHeight = function() { return this.height; };
	this.getLayers = function() { return this.layers; };
}

function LayerDOM(name, x, y, width, height, controls) {
	if(controls == null || controls == undefined) {
		controls = [];
	}

	this.type = "layer";
	this.name = name;
	this.x = x;
	this.y = y;
	this.width = width;
	this.height = height;
	this.controls = controls;

	this.addChild = function(domControlOrGroup) {
		//Sanity check to see if we already had the object
		for(var i = 0; i < this.controls.count(); i++) {
			var item = this.controls.objectAtIndex(i);
			if(item == domControlOrGroup) {
				return;
			}
		}

		this.controls.push(domControlOrGroup);
	}

	// ensure that the x, y, width, and height are integers
	this.x = Math.floor(this.x);
	this.y = Math.floor(this.y);
	this.width = Math.floor(this.width);
	this.height = Math.floor(this.height);

	this.getType = function() { return this.type };
	this.getName = function() { return this.name };
	this.getX = function() { return this.x };
	this.getY = function() { return this.y };
	this.getWidth = function() { return this.width };
	this.getHeight = function() { return this.height };
	//This is both control and group objects
	this.getControls = function() { return this.controls };
}

function GroupDOM(name, x, y, controls) {
	if(controls == null || controls == undefined) {
		controls = [];
	}

	this.type = "group";
	this.name= name;
	this.controls = controls;
	this.x = 0;
	this.y = 0;
	this.width = 0;
	this.height = 0;

	this.addChild = function(domControlOrGroup) {
		//Sanity check to see if we already had the object
		for(var i = 0; i < this.controls.count(); i++) {
			var item = this.controls.objectAtIndex(i);
			if(item == domControlOrGroup) {
				return;
			}
		}

		this.controls.push(domControlOrGroup);
	}

	// offset the x and y position of the storyboard group by the x and y offset of the sketch layer
	this.x += x;
	this.y += y;

	// ensure that the x, y, width, and height are integers
	this.x = Math.floor(this.x);
	this.y = Math.floor(this.y);
	this.width = Math.floor(this.width);
	this.height = Math.floor(this.height);

	this.getType = function() { return this.type };
	this.getName = function() { return this.name };
	this.getX = function() { return this.x };
	this.getY = function() { return this.y };
	this.getWidth = function() { return this.width };
	this.getHeight = function() { return this.height };
	this.getControls = function() { return this.controls };
}

function ControlDOM(name, x, y, width, height, rexts) {
	if(rexts == null || rexts == undefined) {
  	  rexts = [];
    }

	this.type = "control";
	this.name= name;
	this.x = x;
	this.y = y;
	this.width = width;
	this.height = height;
	this.rexts = rexts;
	this.visible = true;

	this.addChild = function(domControlOrGroup) {
		//Sanity check to see if we already had the object
		for(var i = 0; i < this.controls.count(); i++) {
			var layer = this.controls.objectAtIndex(i);
			if(layer == domControlOrGroup) {
				return;
			}
		}

		this.controls.push(domControlOrGroup);
	}

	this.setVisible = function(isVisible) {
		this.visible = isVisible;
	}
	this.getVisible = function() {
		return this.visible;
	}

	// ensure that the x, y, width, and height are integers
	this.x = Math.floor(this.x);
	this.y = Math.floor(this.y);
	this.width = Math.floor(this.width);
	this.height = Math.floor(this.height);

	this.getType = function() { return this.type };
	this.getName = function() { return this.name };
	this.getX = function() { return this.x };
	this.getY = function() { return this.y };
	this.getWidth = function() { return this.width };
	this.getHeight = function() { return this.height };
	this.getRenderExtensions = function() { return this.rexts };
}

function RenderExtension(dom, sourceLayer) {
	this.type = "rext";
	this.sourceLayer = sourceLayer;
	this.x = 0;
	this.y = 0;

	var resourceName = sanitizeName(sourceLayer.name());
	this.filename = dom.getUniqueImageName(resourceName);

	this.name = "image";
	//A switch statement fails here because we aren't JS string
	var className = sourceLayer.class();
	if(className == "MSTextLayer") {
		log("Text Alignment: " + sourceLayer.textAlignment());
		log("Text Vertical Alignment: " + sourceLayer.verticalAlignment());
		//log("Font " + sourceLayer.font());
		var font = sourceLayer.font()
		var fontSize = font.pointSize();
		var fontName = font.fontName();
		//dump_obj(sourceLayer)
		//var fontColor = sourceLayer.textColor();
		//log("Text at " + fontSize + " with " + fontName + " in " + fontColor)
		//log("---")
		this.name = "text";
	} else if(className == "MSBitmapLayer") {
		this.name = "image"
	} else if(className == "MSRectangleLayer") {
		this.name = "rectangle";
	} else if(className == "MSShapeGroup") {
		this.name = "group";
	} else if(className == "MSArtboardGroup") {
		//Use this to synthesize the bg layer
		this.name = "fill";
		this.filename = undefined;
	} else {
	  log("Unhandled render extension type [" + className + "]");
	}

	this.getType = function() { return this.type; };
	this.getName = function() { return this.name; };
	this.getImageResourceName = function() { return this.filename; };
	this.getSourceLayer = function() { return this.sourceLayer; };

	/**
	 * Sketch Alignment values (textAlignment()): Right=1,Center=2,Left=4
	 * GAPP Alignment values: Horz: Left=1,Center=2,Right=3 Vert: Top=1,Center=2,Bottom=3
	 * TODO: Turn this into a fixed cost map lookup
	 */
	this.getGAPPHAlign = function() {
		if(this.sourceLayer.textAlignment == undefined) {
			return 1;
		}
		var align = this.sourceLayer.textAlignment()
		switch((align & 0x7)) {
		case 1: 	//Right
			return 3;
		case 2:		//Center
			return 2;
		case 4:		//Left
		default:	//Default to left
			return 1;
		}
	}

	//We are aligning everything to the top except text
	this.getGAPPVAlign = function() {
		if(this.sourceLayer.textAlignment == undefined) {
			return 1;
		}
		var align = this.sourceLayer.textAlignment()
		//TODO: Determine proper alignemnt by looking at some styles
		return 2;	//Text is center aligned
	}

	/**
	 * Sketch object opacity is set 0-1
	 * GAPP Alpha is set from 0-255
	 */
	this.getGAPPAlpha = function() {
		var style = this.sourceLayer.style();
		return (255 * style.contextSettings().opacity());
	}

	this.getFillColor = function() {
		if((this.sourceLayer.hasBackgroundColor == undefined) || (this.sourceLayer.backgroundColor == undefined)) {
			return undefined;
		}
		var msColor = this.sourceLayer.backgroundColor();
		return makeRGBIntegerFromMSColor(msColor);
	}
}


//Does this sketch layer have child objects
function hasChildren(layer) {
  if (layer.class() != "MSLayerGroup") {
    return false;
  }

  var layers = layer.layers();
  return (layers.length > 0);
}

function isRenderExtension(layer) {
  if (layer.class() == "MSLayerGroup") {
    return false;
  }

  return true;
}

function isControl(layer) {
  var name = layer.name();
  if (hasChildren(layer)) {
    layers = layer.layers();
    for (var i = 0; i < layers.count(); i++) {
      var temp = layers.objectAtIndex(i);
      if (!isRenderExtension(temp)) {
        return false;
      }
    }
    return true;
  } else {
    return isRenderExtension(layer);
  }
}

//Can the sketch layer be an SB group?
function isGroup(layer) {
	var name = layer.name();

	//Design guideline: User indicated they wanted an SB group
	if (name.endsWith("_group")) {
		return true;
	}

	if (!hasChildren(layer)) {
		return false;
	}

	var childLayers = layer.layers();
	for (var i = 0; i < childLayers.count(); i++) {
		var childLayer = childLayers.objectAtIndex(i);
		if (!isControl(childLayer)) {
			return false;
		}
	}

	return true;
}

//Can the sketch layer be an SB layer?
function isLayer(layer) {
	var name = layer.name();

	//Design guideline: User indicated they wanted an SB layer
	if (name.endsWith("_layer")) {
		return true;
	}

	//We don't have any child content, not an SB layer
	if (!hasChildren(layer)) {
	  return false;
	}

	var childLayers = layer.layers();
	for (var i = 0; i < childLayers.count(); i++) {
		var childLayer = childLayers.objectAtIndex(i);
		//We have something illegal in the sub group?
		if (!isGroup(childLayer) && !isControl(childLayer)) {
			return false;
		}
	}

    return true;
}

function DOMBuildControlFromLayer(dom, skLayer, controls) {
	if (skLayer == null) {
		return null;
	}
	domlog("SKLayer => SBControl:" + skLayer.name())

	//Because of the border options (inside/outside/center) we may be larger than
	//the frame so we need to look at the clip rect of the control and use that
	//as the border.
	var frame = skLayer.frame();
	//domlog("Control frame: " + frame.x() + "," + frame.y() + " " + frame.width() + "x" + frame.height());
	var borders = skLayer.style().borders();
	var clipFrame = frame;
	//If we have borders, then we potentially expand the frame
	if(borders != null && borders.count() > 0) {
		var absFrame = skLayer.absoluteRect();
		var sliceLayerAncestry = [MSImmutableLayerAncestry ancestryWithMSLayer:skLayer];
		var rect = [MSSliceTrimming trimmedRectForLayerAncestry:sliceLayerAncestry];
		//domlog("Control abs frame: " + absFrame.x() + "," + absFrame.y() + " " + absFrame.width() + "x" + absFrame.height());
		//domlog("Control clip rect: " + rect.origin.x + "," + rect.origin.y + " " + rect.size.width + "x" + rect.size.height);
		var clipFrameX = frame.x() - (absFrame.x() - rect.origin.x);
		var clipFrameY = frame.y() - (absFrame.y() - rect.origin.y);
		//This delta offset should also be applied to child render extensions ...
		var clipFrameWidth = rect.size.width;
		var clipFrameHeight = rect.size.height;
		clipFrame = MSRect.rectWithX_y_width_height(clipFrameX, clipFrameY, clipFrameWidth, clipFrameHeight);
	}

	var isVisible = skLayer.isVisible();

	//If we don't have any children, then assign ourselves as the rext list
	var subLayers = null;
	if(hasChildren(skLayer)) {
		subLayers = skLayer.layers();
	}
	if(subLayers == null || subLayers == undefined || subLayers.count() == 0) {
		subLayers = [ skLayer ];
	}

	var rexts = []
	var absFrame = skLayer.absoluteRect();
    for(var l = 0; l < subLayers.count(); l++) {
		var subLayer = subLayers.objectAtIndex(l);
		var rext = new RenderExtension(dom, subLayer);
		//Since we may be collapsing children of grouped content into
		//render extensions, we may need to position the render extension
		var absSubFrame = subLayer.absoluteRect();
		rext.x = absSubFrame.x() - absFrame.x();
		rext.y = absSubFrame.y() - absFrame.y();

		rexts.push(rext);
	}

	var controlName = getControlName(skLayer.name(), controls);
	var domControlNode = new ControlDOM(controlName, clipFrame.x(), clipFrame.y(), clipFrame.width(), clipFrame.height(), rexts);

	domControlNode.setVisible(isVisible);

	return domControlNode;
}

function DOMBuildGroupFromLayer(dom, skLayer, peers) {
    if (skLayer == null) {
      return null;
    }
	domlog("SKLayer => SBGroup:" + skLayer.name())

	var groupName = sanitizeName(skLayer.name());
	var frame = skLayer.frame();
	//domlog("SKLayer => SBGroup: " + skLayer.name() + "(" + skLayer.class() + ") @ " + frame.x() + "," + frame.y() + "," + frame.width() + "," + frame.height() + " with " + skLayer.layers().count() + " layers")

	var domChildren = DOMBuildLayerChildrenFromLayerList(dom, skLayer.layers(), true);

	if (groupName == null || groupName == "") {
		// invalid name
		groupName = getControlName("group", peers);
	}

	return new GroupDOM(groupName, frame.x(), frame.y(), domChildren);
}

function DOMBuildLayerChildrenFromLayerList(dom, skLayers, isInGroup) {
	var domLayerChildren = [];

	if (skLayers == null || skLayers.count() <= 0) {
		return domLayerChildren;
	}

	for (var i = 0; i < skLayers.count(); i++) {
		var layer = skLayers.objectAtIndex(i);

		var child = null;
		//If we are trying to make controls from an object and
		//we detect something that has children then we should
		//first try and treat it as a group unless we are already
		//in a group, in which case we should just collapse the
		//content into a control.  Originally it was just checking
		//to see if we could be a group, but that would preclude the skLayer
		//in an skLayer actually being turned into anything
		if ((isGroup(layer) || hasChildren(layer)) && !isInGroup) {
			child = DOMBuildGroupFromLayer(dom, layer, domLayerChildren);
		} else if (isControl(layer)) {
			child = DOMBuildControlFromLayer(dom, layer, domLayerChildren);
		} else {
			//TODO: Dive into a subgroup and start flattening things?
			log("WARNING: Flattening SKLayer: " + layer.name())
			child = DOMBuildControlFromLayer(dom, layer, domLayerChildren);
		}
		if (child != null) {
			domLayerChildren.push(child);
		}
	}

	return domLayerChildren;
}

function DOMBuildLayerExplicit(dom, name, x, y, width, height, domLayerChildren) {
  var domLayer = new LayerDOM(name, x, y, width, height, domLayerChildren);

  //TODO: Change the DOM around to not have to do this
  dom.addLayer(domLayer);

  return domLayer;
}

function DOMBuildSyntheticLayer(dom, frame, skLayerChildList) {
	var name = getLayerName(dom, "Layer");
	var domLayerChildren = DOMBuildLayerChildrenFromLayerList(dom, skLayerChildList, false);
	var newDOMLayer = DOMBuildLayerExplicit(dom, name, 0, 0, frame.width(), frame.height(), domLayerChildren);

	return newDOMLayer;
}

//This function is used to build a SB Layer from a Sketch layer
function DOMBuildLayer(dom, skLayerParent) {
	var frame = skLayerParent.frame();
	var name = getLayerName(dom, skLayerParent.name())
	var domLayerChildren = DOMBuildLayerChildrenFromLayerList(dom, skLayerParent.layers(), false)
	var newDOMLayer = DOMBuildLayerExplicit(dom, name, frame.x(), frame.y(), frame.width(), frame.height(), domLayerChildren);

	return newDOMLayer;
}

function DOMBuildArtboardBGLayer(dom, skArtboardLayer) {
	var frame = skArtboardLayer.frame();
	var name = getLayerName(dom, skArtboardLayer.name() + "Background")
	var domRenderExtension = new RenderExtension(dom, skArtboardLayer);
	var domControl = new ControlDOM("Background", 0, 0, frame.width(), frame.height(), [ domRenderExtension ]);
	var domLayer = new LayerDOM(name, 0, 0, frame.width(), frame.height(), [ domControl ] );

	return domLayer
}


//This routine is used to get a unique name based on the provided name.
//The name is first sanitized and then compared to other existing names to
//ensure that there is no conflict.  Numbers are added to the name until we
//reach the point of no conflict.
function getLayerName(dom, name) {
  return getPeerUniqueName(name, dom.layers);
}

function getControlName(name, controls) {
    return getPeerUniqueName(name, controls);
}

/**
 * Build a screen from the specified Sketch Layer and store it in the provided DOM.
 */
function DOMBuildScreen(dom, skLayerParent) {
	if(skLayerParent == null) {
		return;
	}

    var frame = skLayerParent.frame();
    var layers = skLayerParent.layers();
    domlog("SKLayer => SBScreen: " + skLayerParent.name() + "(" + skLayerParent.class() + ") with " + layers.count() + " layers")

    var domScreenLayers = [];
    var skDeferredLayers = [];

    if(layers == null) {
    	layers = [];
    }

	//Extract the Artboard BG color and create a bg color layer
	if(skLayerParent.class() == "MSArtboardGroup") {
		if(skLayerParent.hasBackgroundColor()) {
			var msColor = skLayerParent.backgroundColor();
			var iColor = makeRGBIntegerFromMSColor(msColor);
			log("I Have Background Color 0x" + iColor.toString(16));
			var domBGLayer = DOMBuildArtboardBGLayer(dom, skLayerParent);
			domScreenLayers.push(domBGLayer);
		}
	}

	for (var i = 0; i < layers.count(); i++) {
		var skLayer = layers.objectAtIndex(i);
		if (skLayer == null || skLayer == undefined) {
		  continue;
		}

		//Any layer that has child content under the root is 'layerable'
		if (hasChildren(skLayer) || isLayer(skLayer) || isGroup(skLayer)) {
			domlog("SKLayer => SBLayer: " + skLayer.name());
			//Push any accumulated controls to their own synthetic layer ...
			if (skDeferredLayers.length > 0) {
				var domLayer = DOMBuildSyntheticLayer(dom, frame, skDeferredLayers);
				domScreenLayers.push(domLayer);
				skDeferredLayers = [];
			}

			var domLayer = DOMBuildLayer(dom, skLayer);
			domScreenLayers.push(domLayer);
		} else {
			domlog("SKLayer => Deferred (SBControl/SBGroup): " + skLayer.name());
			skDeferredLayers.push(skLayer);
		}
    }

    //Any lingering content should be pushed to a layer
	if (skDeferredLayers.length > 0) {
		var domLayer = DOMBuildSyntheticLayer(dom, frame, skDeferredLayers);
		domScreenLayers.push(domLayer);
	}

    domlog("Creating screen " + skLayerParent.name() + " with " + domScreenLayers.count() + " layers ");
	var screenName = sanitizeName(skLayerParent.name());
    var screen = new ScreenDOM(screenName, frame.width(), frame.height(), domScreenLayers);
    dom.addScreen(screen);
}
