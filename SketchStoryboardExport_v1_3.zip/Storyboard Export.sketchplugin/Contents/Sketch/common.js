Array.prototype.count = function() {
  return this.length;
}

Array.prototype.objectAtIndex = function(i) {
  return this[i];
}

// Dump Object
function dump_obj(obj){
  log("#####################################################################################")
  log("## Dumping object " + obj )
  log("## obj class is: " + [obj className])
  log("#####################################################################################")

  log("obj.properties:")
  log([obj class].mocha().properties())
  log("obj.propertiesWithAncestors:")
  log([obj class].mocha().propertiesWithAncestors())

  log("obj.classMethods:")
  log([obj class].mocha().classMethods())
  log("obj.classMethodsWithAncestors:")
  log([obj class].mocha().classMethodsWithAncestors())

  log("obj.instanceMethods:")
  log([obj class].mocha().instanceMethods())
  log("obj.instanceMethodsWithAncestors:")
  log([obj class].mocha().instanceMethodsWithAncestors())

  log("obj.protocols:")
  log([obj class].mocha().protocols())
  log("obj.protocolsWithAncestors:")
  log([obj class].mocha().protocolsWithAncestors())

  log("obj.treeAsDictionary():")
  log(obj.treeAsDictionary())
}

function getExportBasePathFromUser() {
	//allow xml to be written to the folder
	//var fileTypes = [NSArray arrayWithObjects:@"gapp", nil];

	//create select folder window
	var panel = [NSOpenPanel openPanel];
	[panel setCanChooseDirectories:true];
	[panel setCanCreateDirectories:true];
	[panel setCanChooseFiles:false];
	//[panel setAllowedFileTypes:fileTypes];
  	//[panel setTitle:"Select A Directory"]

	//create variable to check if clicked
	var clicked = [panel runModal];
	//check if clicked
	if (clicked != NSFileHandlingPanelOKButton) {
  		return null;
	}

  	var isDirectory = true;
  	//get the folder path
  	var firstURL = [[panel URLs] objectAtIndex:0];
  	//format it to a string
  	var file_path = [NSString stringWithFormat:@"%@", firstURL];

  	//remove the file:// path from string
  	if (0 === file_path.indexOf("file://")) {
    	file_path = file_path.substring(7);
  	}

	//remove the trailing / from the string
	if(file_path.endsWith("/")) {
		file_path = file_path.substring(0, file_path.length - 1);
	}

	return file_path;
}

/**
 * Return the URL for the current sketch file.
 */
function getSketchFileURL(context) {
	return context.document.fileURL();
}

/**
 * Return the filename component only of the current sketch file
 */
function getSketchFileName(context) {
	var url = getSketchFileURL(context);
	return url.lastPathComponent();
}
