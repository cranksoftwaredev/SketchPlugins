@import "common.js"
@import "storyboard_dom.js"
@import "storyboard_writer.js"

var pluginVersion = "0.0.1";
var sketchDoc;
var nsDoc;
var sketchApp;
var tempFolder;

var enabledExportTextAsImage;
var sketchAPI;
var lastContext;

function sendUIMessage(msg) {
	if (sketchAPI != null) {
		sketchAPI.message(msg);
	}
}

function storeContextGlobals(context) {
	lastContext = context;
	if (context.headless == null) {
		sketchAPI = require("sketch/ui");
	}
}

function getArtboards(page) {
  if (page == null) {
    return [];
  }

  return page.artboards();
}

function getPages(context) {
	var document = context.document;
	if (document == null) {
    	return [];
  	}

	return document.pages();
}

function NormalizeLayers(dom) {
	var left = 0, top = 0;

	var screens = dom.getScreens();
	if(screens.count() != 1) {
		return;
	}
	var screen = screens.objectAtIndex(0);
	var layers = screen.getLayers();
	for(var l = 0; l < layers.count(); l++) {
		var layer = layers.objectAtIndex(l);
		if(layer.x < left) {
			left = layer.x;
		}
		if(layer.y < top) {
			top = layer.y;
		}
	}

	log("NORMALIZE to " + left + "," + top)
}

function buildExportFilename(context) {
	var baseDir = getExportBasePathFromUser();
	if(baseDir == null) {
		log("Missing base path for export");
		return;
	}

	var sketchFileName = getSketchFileName(lastContext);
	var extensionlessFileName = sketchFileName.substring(0, sketchFileName.lastIndexOf('.'));
	if(extensionlessFileName == undefined) {
		extensionlessFileName = sketchFileName
	}

	baseDir = baseDir + "/Sketch2Storyboard_" + extensionlessFileName

	//Make sure that our base dir actually exists
	var dirNSString = NSString.pathWithComponents([baseDir]);
	NSFileManager.defaultManager().createDirectoryAtPath_withIntermediateDirectories_attributes_error(dirNSString, true, null, null);

	//Then decide what our filename should be
	var gappFileName = extensionlessFileName + ".gapp"
	log("Reading Document: " + gappFileName)

	return baseDir + "/" + gappFileName
}

function performExport(context, roots) {
	storeContextGlobals(context)

	var modelFilename = buildExportFilename(context)
	if(modelFilename == undefined) {
 		sendUIMessage("Unable to create Storyboard model path");
		return;
	}
	var baseDir = modelFilename.substring(0, modelFilename.lastIndexOf('/'))

	var dom = new StoryboardDOM(context);

	for(var i = 0; i < roots.count(); i++) {
		var root = roots.objectAtIndex(i);
		DOMBuildScreen(dom, root);
	}

	//TODO: Normalize the position(s) of the layers if we have a single root
	// if(roots.count == 1 && roots[0].class() == "MSPage") {
	// 	NormalizeLayers(dom);
	// }

	//Do stuff with the generated DOM
	//Debugging ... display the DOM we discovered
	var cb = getDOMPrintVisitor();
    visitDOM(dom, cb);

	writeGAPPFile(dom, modelFilename));
	writeGAPPAssets(context.document, dom, baseDir);

	return modelFilename;
}

// ## Main Handler
function onExportFullDesign(context) {
	storeContextGlobals(context)

	var pages = getPages(context);
    log("Discovered " + pages.count() + " pages");

    //For each page, look for an artboard (favoured) or if no artboards the content
	var roots = []

	for( var p = 0; p < pages.count(); p++) {
    	var page = pages.objectAtIndex(p);
    	var artboards = getArtboards(page);
    	log("Discovered " + artboards.count() + " artboards on page " + page.name());
		for (var a = 0; a < artboards.count(); a++) {
			var artboard = artboards.objectAtIndex(a);
			roots.push(artboard);
		}
      	if(artboards.count() == 0) {
			roots.push(page);
        }
    }

	if(roots.count() == 0) {
		sendUIMessage("No pages or artboards available to export.");
		return
	}

	var modelFilename = performExport(context, roots);

	sendUIMessage("Content exported to " + modelFilename);
}

function onExportSelection(context) {
 	var selection = context.selection;

	var roots = []
	for(i=0; i < selection.count() ; i++) {
		var layer = selection.objectAtIndex(i);
		//When a page is selected, favour pushing the artboards on the page rather than the page itself.
		if(layer.class() == "MSPage") {
			var artboards = getArtboards(layer);
			for(var a = 0; a < artboards.count(); a++) {
				roots.push(artboards.objectAtIndex(a));
			}
			if(artboards.count() == 0) {		//No artboards, push the page
				roots.push(layer);
			}
		//When specific artboards are selected, export those directly
		} else if(layer.class() == "MSArtboardGroup") {
			roots.push(layer)
		}

	}

	if(roots.count() == 0) {
		sendUIMessage("Please select at least one artboard to export.");
		return
	}

	var modelFilename = performExport(context, roots);

	sendUIMessage("Content exported to " + modelFilename)
}
